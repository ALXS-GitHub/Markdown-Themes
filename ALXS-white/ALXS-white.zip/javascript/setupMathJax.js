window.MathJax = {
    tex: {
        inlineMath: [["$", "$"]],
        processEscapes: true,
        displayMath: [["$$", "$$"]],
    },
};
